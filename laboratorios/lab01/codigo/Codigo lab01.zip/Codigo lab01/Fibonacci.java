
/**
 * Esta clase toma el tiempo de ejecucion del calculo de una serie de fibonacci de manera recursiva 
 * 
 * @Eduard Damiam
 * @Esteban Osorio
 * @0.01
 */
public class Fibonacci
{
  /**
   * Este metodo calcula una serie de fibonacci de longitu n
   */
  public static long fibonacci(int n) {
        if (n <= 1) {
            return n;
          }else{ return fibonacci(n-1) + fibonacci(n-2);
        }
  }
  
  /**
   * Este es el main de la clase
   * calcula el tiempo de ejecucion de fibonacci
   */
  public static void main(String[] args, int n){
         long startTime = System.currentTimeMillis();
         fibonacci(n);
         long estimatedTime = System.currentTimeMillis() - startTime;       
         System.out.println(estimatedTime);
  }
}
